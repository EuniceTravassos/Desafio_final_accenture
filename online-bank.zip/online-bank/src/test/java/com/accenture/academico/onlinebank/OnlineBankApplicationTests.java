package com.accenture.academico.onlinebank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineBankApplicationTests {

	@Test
	void contextLoads() {
	}

}
